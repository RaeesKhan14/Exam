import pandas as pd
import sqlite3
import time
import random
import threading
import matplotlib.pyplot as plt
import seaborn as sns

# Load and clean the survey data from CSV

df = pd.read_csv("FitnessTrackerDataAnalysis.csv")
df = df.dropna(how="all")

selected_columns = ['Age', 'Gender', 'Brand', 'RealTimeAlerts']

def find_col(df_cols, tokens):
    for col in df_cols:
        for t in tokens:
            if t.lower() in col.lower():
                return col
    return None

cols_map = {
    'Age': find_col(df.columns, ['age']),
    'Gender': find_col(df.columns, ['gender', 'sex']),
    'Brand': find_col(df.columns, ['brand', 'tracker', 'device']),
    'RealTimeAlerts': find_col(df.columns, ['alerts', 'realtime', 'reminder'])
}

if any(v is None for v in cols_map.values()):
    raise SystemExit("Required columns not found in CSV.")

df_selected = df[[cols_map[c] for c in selected_columns]].rename(columns={
    cols_map['Age']: 'Age',
    cols_map['Gender']: 'Gender',
    cols_map['Brand']: 'Brand',
    cols_map['RealTimeAlerts']: 'RealTimeAlerts'
})

df_selected['Age'] = pd.to_numeric(df_selected['Age'], errors='coerce')
df_selected = df_selected.dropna(subset=['Age', 'Gender'])

# Store it in SQLite 

conn = sqlite3.connect("survey_responses.db")
df_selected.to_sql("survey_responses", conn, if_exists="replace", index=False)
conn.close()

# Activity 2: Analysis & Visualisation 

def age_summary(data):
    print("\nAge summary:")
    print(data['Age'].describe())
    sns.histplot(data['Age'], bins=15)
    plt.title("Age Distribution")
    plt.savefig("age_distribution.png")
    plt.show()

def categorical_summary(data, col, title, filename):
    counts = data[col].value_counts()
    sns.barplot(x=counts.index, y=counts.values)
    plt.title(title)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(filename)
    plt.show()

age_summary(df_selected)
categorical_summary(df_selected, "Gender", "Gender Distribution", "gender.png")
categorical_summary(df_selected, "Brand", "Fitness Tracker Brand", "brand.png")
categorical_summary(df_selected, "RealTimeAlerts", "Real-Time Alerts Usage", "alerts.png")

# Activity 3: Concurrency using SAME variables 

def simulate_user_submission(user_id, delay=0.02):
    """Simulate one user submitting survey data"""
    time.sleep(delay)
    return {
        "Age": random.randint(18, 65),
        "Gender": random.choice(["Male", "Female", "Other"]),
        "Brand": random.choice(["Fitbit", "Apple", "Garmin", "Samsung"]),
        "RealTimeAlerts": random.choice(["Yes", "No"])
    }

def sequential_processing(num_users):
    start = time.perf_counter()
    results = [simulate_user_submission(u) for u in range(num_users)]
    duration = time.perf_counter() - start
    print(f"Sequential time: {duration:.3f}s")
    return results, duration

def threaded_processing(num_users):
    start = time.perf_counter()
    results = []
    lock = threading.Lock()

    def worker(uid):
        data = simulate_user_submission(uid)
        with lock:
            results.append(data)

    threads = []
    for u in range(num_users):
        t = threading.Thread(target=worker, args=(u,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    duration = time.perf_counter() - start
    print(f"Threaded time: {duration:.3f}s")
    return results, duration

# Run Activity 3 

if __name__ == "__main__":
    print("\nActivity 3: Concurrency Test\n")
    users = 10
    seq_data, seq_time = sequential_processing(users)
    thr_data, thr_time = threaded_processing(users)

    # Performance comparison chart
    times_df = pd.DataFrame({
        "Mode": ["Sequential", "Threaded"],
        "Time (s)": [seq_time, thr_time]
    })

    sns.barplot(x="Mode", y="Time (s)", data=times_df)
    plt.title("Sequential vs Threaded Survey Submissions")
    plt.savefig("concurrency_comparison.png")
    
    plt.show()
