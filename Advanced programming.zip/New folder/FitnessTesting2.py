import unittest
import pandas as pd
import threading
import random
import time


# Main function 


def simulate_user_submission(user_id, delay=0.02):
    """Simulate one user submitting survey data"""
    time.sleep(delay)
    return {
        "Age": random.randint(18, 65),
        "Gender": random.choice(["Male", "Female", "Other"]),
        "Brand": random.choice(["Fitbit", "Apple", "Garmin", "Samsung"]),
        "RealTimeAlerts": random.choice(["Yes", "No"]),
        "Steps": random.randint(0, 20000)
    }

# Example analysis function

def average_steps(data):
    """Return average steps from a list of submissions"""
    steps = [entry["Steps"] for entry in data]
    return sum(steps) / len(steps) if steps else 0


# Unit Tests


class TestFitnessFunctions(unittest.TestCase):

    # Error Handling Tests 

    def test_missing_csv(self):

        """Missing CSV file should raise FileNotFoundError"""
        with self.assertRaises(FileNotFoundError):
            pd.read_csv("non_existent_file.csv")

    def test_empty_csv(self):

        """Empty CSV should raise a ValueError"""
        df = pd.DataFrame()  # simulating an empty CSV
        with self.assertRaises(ValueError):
            if df.empty:
                raise ValueError("CSV is empty")

    def test_invalid_age(self):

        """Test invalid ages"""
        df = pd.DataFrame({"Age": ["twenty", -5, 2.5]})
        df['Age'] = pd.to_numeric(df['Age'], errors='coerce')
        invalid = df['Age'].isna() | (df['Age'] < 0)
        self.assertTrue(invalid.any())

    def test_invalid_steps(self):

        """Test negative step counts"""

        df = pd.DataFrame({"Steps": [1000, -5, 5000]})
        invalid = df['Steps'] < 0
        self.assertTrue(invalid.any())

    #  Data Ingestion Tests 

    def test_data_ingestion(self):

        """Test that required CSV columns exist"""
        df = pd.DataFrame({
            "Age": [-1,12 ],
            "Gender": ["Male", "Female"],
            "Steps": [0, 0]
        })
        self.assertIn("Age", df.columns)
        self.assertIn("Gender", df.columns)
        self.assertIn("Steps", df.columns)

    #  Analysis Function Tests 

    def test_simulate_user_submission(self):

        """Check simulate_user_submission returns correct keys and types"""
        result = simulate_user_submission(1)
        self.assertIn("Age", result)
        self.assertIn("Gender", result)
        self.assertIn("Brand", result)
        self.assertIn("RealTimeAlerts", result)
        self.assertIn("Steps", result)
        self.assertIsInstance(result["Age"], int)
        self.assertIsInstance(result["Steps"], int)
        self.assertIn(result["Gender"], ["Male", "Female", "Other"])

    def test_average_steps(self):

        """Check average_steps function"""

        data = [simulate_user_submission(i) for i in range(3)]
        avg = average_steps(data)
        self.assertTrue(isinstance(avg, (int, float)))
        self.assertGreaterEqual(avg, 0)

    # Threading Test 

    def test_threading_safety(self):
        
        """Test safe threading when appending to a list"""

        results = []
        lock = threading.Lock()

        def worker(uid):
            with lock:
                results.append(uid)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(len(results), 5)


# Run Tests and print the summary


if __name__ == "__main__":

    print("\nRunning Full Fitness Testing Suite...\n")
    
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestFitnessFunctions)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)


    print("Fitness Testing Completed!")
    print(f"Total tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    if result.wasSuccessful():
        print("All tests passed successfully ")
    else:
        print("Some tests failed ")

